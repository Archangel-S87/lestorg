<?php

// exit if accessed directly
if (!defined('ABSPATH')) exit;

// check if class already exists
if (empty(WC_ABSPATH) || class_exists('NAMESPACE_acf_field_FIELD_NAME')) return;


class woocommerce_acf_field_product_attributes extends acf_field
{
    private $settings = [];

    public function __construct($settings)
    {
        $this->settings = $settings;
        $this->name = 'product_attributes';
        $this->label = 'Атрибуты товара';
        $this->category = 'WooCommerce';
        $this->defaults = [
            'product_id' => 0,
            'default_value' => [
                'attribute_name' => '',
                'attribute_label' => '',
                'term_id' => 0,
                'term_label' => ''
            ],
            'choices' => [],
            'ui' => true,
            'ajax' => true,
            'ajax_action' => 'acf/fields/product_attributes/query'
        ];

        // ajax
        add_action('wp_ajax_acf/fields/product_attributes/query', [$this, 'ajax_query']);
        add_action('wp_ajax_nopriv_acf/fields/product_attributes/query', [$this, 'ajax_query']);

        parent::__construct();
    }

    public function ajax_query()
    {
        $response = $this->get_ajax_query($_POST);
        acf_send_ajax_results($response);
    }

    function get_ajax_query($data = array())
    {
        $data = acf_parse_args($data, array(
            'post_id' => 0,
            'taxonomy_name' => '',
        ));

        $name = $data['taxonomy_name'];

        if (!$name) return false;

        $terms = get_terms([
            'taxonomy' => wc_attribute_taxonomy_name($name),
            'hide_empty' => false
        ]);

        if (!$terms || is_wp_error($terms)) return false;

        $results = [];
        foreach ($terms as $term) {
            $results[$term->term_id] = $term->name;
        }

        return [
            'results' => $results
        ];
    }

    /*
    *  render_field_settings()
    *
    *  Create extra settings for your field. These are visible when editing a field
    *
    *  @param	$field (array) the $field being edited
    *  @return	n/a
    */

    public function render_field_settings($field)
    {
        acf_render_field_setting($field, [
            'label' => 'Product ID',
            'instructions' => 'Укажите ID товара',
            'type' => 'number',
            'name' => 'product_id'
        ]);
    }

    /*
     * Поле со списком атрибутов taxonomy_id
     */
    public function get_field_product_attributes($field)
    {
        global $post;

        $product = wc_get_product($post);

        $choices = ['' => ''];

        if ($product) {
            $field['product_id'] = $product->get_id();
            $args = wc_get_attribute_taxonomies();
            $args = apply_filters('acf/fields/product_attributes/wp_attribute_taxonomies', $args, $field);
            $args = apply_filters('acf/fields/product_attributes/wp_attribute_taxonomies/name=' . $field['_name'], $args, $field);
            $args = apply_filters('acf/fields/product_attributes/wp_attribute_taxonomies/key=' . $field['key'], $args, $field);

            foreach ($args as $arg) {
                $choices[$arg->attribute_name] = $arg->attribute_label;
            }
        }

        $value = acf_get_array($field['value']);

        acf_select_input([
            'id' => $field['id'] . '_attribute_name-input',
            'name' => $field['name'] . '[attribute_name]',
            'value' => $value['attribute_name'],
            'choices' => $choices,
            'class' => 'product-attributes-attribute-name',
            'data-product_id' => $field['product_id'],
            'data-ui' => $field['ui'],
            'data-ajax' => $field['ajax'],
            'data-ajax_action' => $field['ajax_action']
        ]);
    }

    private function get_field_term_id($field)
    {
        global $post;

        $product = wc_get_product($post);

        $value = acf_get_array($field['value']);
        $attribute_name = $value ? $value['attribute_name'] : '';

        $choices = [];

        if ($product && $attribute_name) {
            $args = [
                'taxonomy' => wc_attribute_taxonomy_name($value['attribute_name']),
                'hide_empty' => false
            ];
            $args = apply_filters('acf/fields/product_attributes/term_id', $args, $field);
            $args = apply_filters('acf/fields/product_attributes/term_id/name=' . $field['_name'], $args, $field);
            $args = apply_filters('acf/fields/product_attributes/term_id/key=' . $field['key'], $args, $field);
            $args = get_terms($args);

            if (!is_wp_error($args)) {
                foreach ($args as $term) {
                    $choices[$term->term_id] = $term->name;
                }
            }
        }

        acf_select_input([
            'id' => $field['id'] . '_term_id-input',
            'name' => $field['name'] . '[term_id]',
            'value' => $value['term_id'],
            'choices' => $choices,
            'class' => 'product-attributes-term_id',
            'data-product_id' => $field['product_id'],
            'data-ui' => $field['ui'],
            'data-ajax' => $field['ajax'],
            'ata-ajax_action' => $field['ajax_action']
        ]);
    }

    /*
    *  render_field()
    *
    *  Create the HTML interface for your field
    *
    *  @param	$field (array) the $field being rendered
    *  @param	$field (array) the $field being edited
    *  @return	n/a
    */

    public function render_field($field)
    {
        acf_hidden_input([
            'id' => $field['id'] . '-input',
            'name' => $field['name'],
            'data-field_type' => $this->name
        ]);

        echo '<div class="acf-row wrapper-product-attributes">';
        echo '<div class="wrapper-input">';
        $this->get_field_product_attributes($field);
        echo '</div><div class="wrapper-input">';
        $this->get_field_term_id($field);
        echo '</div></div>';
    }

    /*
    *  input_admin_enqueue_scripts()
    *
    *  This action is called in the admin_enqueue_scripts action on the edit screen where your field is created.
    *  Use this action to add CSS + JavaScript to assist your render_field() action.
    *
    *  @param	n/a
    *  @return	n/a
    */

    function input_admin_enqueue_scripts()
    {
        // vars
        $url = $this->settings['url'];
        $version = $this->settings['version'];

        // register & include JS
        wp_register_script($this->name, "{$url}assets/js/input.js", array('acf-input'), $version);
        wp_enqueue_script($this->name);

        // register & include CSS
        wp_register_style($this->name, "{$url}assets/css/input.css", array('acf-input'), $version);
        wp_enqueue_style($this->name);
    }

    /*
    *  validate_value()
    *
    *  This filter is used to perform validation on the value prior to saving.
    *  All values are validated regardless of the field's required setting. This allows you to validate and return
    *  messages to the user if the value is not correct
    *
    *  @param	$valid (boolean) validation status based on the value and the field's required setting
    *  @param	$value (mixed) the $_POST value
    *  @param	$field (array) the field array holding all the field options
    *  @param	$input (string) the corresponding input name for $_POST value
    *  @return	$valid
    */

    function validate_value($valid, $value, $field, $input)
    {
        return $value['attribute_name'] ? true : 'Опция не может быть пустой';
    }

    /*
    *  update_value()
    *
    *  This filter is applied to the $value before it is saved in the db
    *
    *  @param	$value (mixed) the value found in the database
    *  @param	$post_id (mixed) the $post_id from which the value was loaded
    *  @param	$field (array) the field array holding all the field options
    *  @return	$value
    */

    function update_value($value, $post_id, $field)
    {
        $attr_id = wc_attribute_taxonomy_id_by_name($value['attribute_name']);
        $attr = wc_get_attribute($attr_id);
        $value['attribute_label'] = $attr->name;
        $term = get_term($value['term_id'], wc_attribute_taxonomy_name($value['attribute_name']));
        $value['term_label'] = $term->name;
        return $value;
    }
}

// initialize
new woocommerce_acf_field_product_attributes($this->settings);


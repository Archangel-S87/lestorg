(function ($) {

    let productAttributes = acf.Field.extend({
        type: 'product_attributes',
        ajaxAction: 'acf/fields/product_attributes/query',
        // Select со атрибутами
        selectAttrs: null,
        // Select со значениями
        selectVal: null,
        events: {
            'change select.product-attributes-attribute-name': 'onChange'
        },
        onChange: function (e, $el) {
            this.getAjax({
                taxonomy_name: $el.val()
            });
        },
        initialize: function () {
            this.selectAttrs = this.$('select.product-attributes-attribute-name');
            this.selectVal = this.$('select.product-attributes-term_id');
            console.log(this.selectVal);
        },
        getAjax: function (ajaxData) {
            let $this = this;
            ajaxData.action = this.ajaxAction;
            $.ajax({
                url: acf.get('ajaxurl'),
                data: acf.prepareForAjax(ajaxData),
                type: 'post',
                dataType: 'json',
                success: function (res) {
                    if (!res && !res.results) return false;
                    $this.insertTerms(res.results);
                }
            });
        },
        getOption(value, label) {
            return '<option value="' + value + '" data-id="' + value + '">' + label + '</option>'
        },
        insertTerms: function (list) {
            let html = '';
            for (let id in list) {
                html += this.getOption(id, list[id]);
            }
            this.selectVal.html(html);
        }
    });

    acf.registerFieldType(productAttributes);

    /**
     *  initialize_field
     *
     *  This function will initialize the $field.
     *
     *  @param    n/a
     *  @return    n/a
     */

    function initialize_field($field) {}


    if (typeof acf.add_action !== 'undefined') {

        /*
        *  ready & append (ACF5)
        *
        *  These two events are called when a field element is ready for initizliation.
        *  - ready: on page load similar to $(document).ready()
        *  - append: on new DOM elements appended via repeater field or other AJAX calls
        *
        *  @param	n/a
        *  @return	n/a
        */

        acf.add_action('ready_field/type=product_attributes', initialize_field);
        acf.add_action('append_field/type=product_attributes', initialize_field);


    } else {

        /*
        *  acf/setup_fields (ACF4)
        *
        *  These single event is called when a field element is ready for initizliation.
        *
        *  @param	event		an event object. This can be ignored
        *  @param	element		An element which contains the new HTML
        *  @return	n/a
        */

        $(document).on('acf/setup_fields', function (e, postbox) {

            // find all relevant fields
            $(postbox).find('.field[data-field_type="product_attributes"]').each(function () {

                // initialize
                initialize_field($(this));

            });

        });

    }

})(jQuery);
